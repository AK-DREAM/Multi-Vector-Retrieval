#!/usr/bin/env bash

cd box_intersections_cpu
python setup.py build_ext --inplace
